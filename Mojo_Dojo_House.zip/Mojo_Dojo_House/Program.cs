﻿namespace Mojo_Dojo_House
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to our Mojo Dojo House");
        }
    }
}
