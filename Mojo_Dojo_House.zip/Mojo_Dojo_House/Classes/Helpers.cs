﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mojo_Dojo_House.Classes
{
    internal class Helpers
    {
        public int MyProperty { get; set; }
        public double MyProperty1 { get; set; }
        public  string MyProperty2 { get; set; }
        public int MyProperty3 { get; set; }
    }
}
